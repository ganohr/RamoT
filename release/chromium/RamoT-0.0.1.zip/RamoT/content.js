let already_running = document.getElementById('#ganohrs-ramot');
if (already_running === null) {
	let dummy = document.createElement('b');
	dummy.id = 'ganohrs-ramot';
	document.body.appendChild(dummy);
	setInterval(()=>{
		document.querySelectorAll(
			'svg[aria-label="認証済みアカウント"] g path:first-child'
		).forEach(
			e => e.getAttribute("clip-rule") !== "evenodd"
				&& e.parentNode.parentNode.remove()
		)
	},10);
}
